import 'package:flutter/material.dart';

class RegFields {
  static getAll() {
    return _fields;
  }

  static final Map<String, dynamic> _fields = {
    'email': {
      'controller': TextEditingController(),
      'label': 'Email!',
      'hint': 'example@mail.ru',
      'obscure': false,
      'validator': (value) => validateEmail(value) as String?,
    },
    'password': {
      'controller': TextEditingController(),
      'label': 'Password',
      'hint': 'Password',
      'obscure': true,
      'validator': (value) => validatePassword(value) as String?,
    },
    'phone': {
      'controller': TextEditingController(),
      'label': 'Мобильный телефон',
      'hint': 'Мобильный телефон',
      'obscure': false,
      'validator': (value) => validatePhone(value) as String?,
    },
    'firstName': {
      'controller': TextEditingController(),
      'label': 'First Name',
      'hint': 'First Name',
      'obscure': false,
      'validator': (value) => validateName(value) as String?,
    },
    'lastName': {
      'controller': TextEditingController(),
      'label': 'Last Name',
      'hint': 'Last Name',
      'obscure': false,
      'validator': (value) => validateName(value) as String?,
    }
  };

  static validatePhone(value) {
    print(value);
    return null;
  }

  static validateName(value) {
    if (value.length == 0) return 'ploho';
    return null;
  }

  static validatePassword(value) {
    return null;
  }

  static validateEmail(v) {
    //return 'ploho';
    return null;
  }
}
