
class SpecialistModel {
  String img;
  String  name;
  String noOfDoctors;
  SpecialistModel(
    {required this.img,required this.name,required this.noOfDoctors}
  );
}