

class ReviewsModel{
  String name, img , review;
  ReviewsModel(
    {
      required this.img,required this.name,required this.review
    }
  );
}