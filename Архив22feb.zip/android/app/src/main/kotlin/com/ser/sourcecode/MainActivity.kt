package com.ser.sourcecode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
