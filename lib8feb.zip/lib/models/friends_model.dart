class FriendsModel {
  String name, img;
  FriendsModel({

    required this.name,required this.img
  });
}