
class ChatModel {
  String msg;
  bool isMine;
  ChatModel({
    required this.msg,
    required this.isMine,
     });
}