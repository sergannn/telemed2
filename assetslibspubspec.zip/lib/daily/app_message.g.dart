// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_message.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Map<String, dynamic> _$$MessageImplToJson(_$MessageImpl instance) =>
    <String, dynamic>{
      'event': instance.event,
      'fromParticipantId': instance.fromParticipantId,
      'data': instance.data,
      'runtimeType': instance.$type,
    };

Map<String, dynamic> _$$ChatMessageImplToJson(_$ChatMessageImpl instance) =>
    <String, dynamic>{
      'message': instance.message,
      'runtimeType': instance.$type,
    };

Map<String, dynamic> _$$ChatMessageReactionImplToJson(
        _$ChatMessageReactionImpl instance) =>
    <String, dynamic>{
      'reaction': instance.reaction,
      'runtimeType': instance.$type,
    };
