class AppointmentsModel {
  String img, name, contactMethodIcon, status, time, id;
  AppointmentsModel(
      {required this.img,
      required this.name,
      required this.id,
      required this.contactMethodIcon,
      required this.status,
      required this.time});
}
