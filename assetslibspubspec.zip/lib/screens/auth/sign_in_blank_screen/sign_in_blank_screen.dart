import 'package:daily_flutter/daily_flutter.dart';
import 'package:doctorq/app_export.dart';
import 'package:doctorq/daily/main.dart';
import 'package:doctorq/screens/appointments/AppointmentsScreenDoctor.dart';
import 'package:doctorq/screens/main_screen.dart';
import 'package:doctorq/screens/auth/forgot/password_method_screen/password_method_screen.dart';
import 'package:doctorq/services/api_service.dart';
import 'package:doctorq/services/auth_service.dart';
import 'package:doctorq/utils/pub.dart';
import 'package:doctorq/widgets/custom_button.dart';
import 'package:doctorq/widgets/custom_checkbox.dart';
import 'package:doctorq/widgets/custom_text_form_field.dart';
import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../widgets/boxshadow.dart';
import '../../../widgets/spacing.dart';
import '../sign_up_blank_screen/sign_up_blank_screen.dart';
import 'doctor_screen.dart';

import 'package:flutter_login_yandex/flutter_login_yandex.dart';

class SignInBlankScreen extends StatefulWidget {
  const SignInBlankScreen({Key? key}) : super(key: key);

  @override
  State<SignInBlankScreen> createState() => _SignInBlankScreenState();
}

class _SignInBlankScreenState extends State<SignInBlankScreen> {
  bool checkbox = false;
  bool obscure = true;
  String _token = '';
  final _flutterLoginYandexPlugin = FlutterLoginYandex();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final _isFormValid = ValueNotifier(false);

  gogo(isDark) {
    showDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      barrierDismissible: true,
      context: context,
      builder: (context) {
        Future.delayed(const Duration(milliseconds: 600), () {
          Navigator.of(context).pop(true);

          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (context) => Main() //user: user
//                                          uId: id,
                  ),
              (Route<dynamic> route) => false);
        });
        return Dialog(
            backgroundColor: Colors.transparent,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(
                Radius.circular(15.0),
              ),
            ),
            elevation: 0.0,
            child: Center(
              child: Container(
                width: getHorizontalSize(124),
                height: getVerticalSize(124),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: isDark
                        ? ColorConstant.darkBg
                        : ColorConstant.whiteA700),
                child: Center(
                    child: CircularProgressIndicator(
                  color: ColorConstant.blueA400,
                  backgroundColor: ColorConstant.blueA400.withOpacity(.3),
                )),
              ),
            ));
      },
    );
  }

  forceLog() async {
    var authRes = await authUser(context, "john@example.com", "123456");
    if (authRes == true) {
      gogo(false);
/*      showDialog(
          barrierColor: Colors.black.withOpacity(0.5),
          barrierDismissible: true,
          context: context,
          builder: (context) {
            Future.delayed(const Duration(milliseconds: 600), () {
              Navigator.of(context).pop(true);

              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (context) => Main() //user: user
//                                          uId: id,
                      ),
                  (Route<dynamic> route) => false);
            });
            return Dialog(
                backgroundColor: Colors.transparent,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(
                    Radius.circular(15.0),
                  ),
                ),
                elevation: 0.0,
                child: Center(
                  child: Container(
                    width: getHorizontalSize(124),
                    height: getVerticalSize(124),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: ColorConstant.darkBg),
                    child: Center(
                        child: CircularProgressIndicator(
                      color: ColorConstant.blueA400,
                      backgroundColor: ColorConstant.blueA400.withOpacity(.3),
                    )),
                  ),
                ));
          });*/
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isDark = Theme.of(context).brightness == Brightness.dark;
    bool isRtl = context.locale == Constants.arLocal;
    return Scaffold(
        // floatingActionButton:
        //   FloatingActionButton(onPressed: null, child: Text("a")),
        body: SafeArea(
            child: SingleChildScrollView(
                child: Column(
      //mainAxisSize: MainAxisSize.max,
      //mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Align(
            alignment: Alignment.topLeft,
            child: Padding(
              padding: getPadding(
                left: 16,
                top: 30,
                right: 24,
              ),
              child: Container(
                width: MediaQuery.of(context).size.width / 2,
                child: Image.asset(
                  ImageConstant.appLogoAnn,
                  fit: BoxFit.contain,
                ),
              ),
            )),
        Align(
          alignment: Alignment.centerLeft,
          child: Padding(
            padding: getPadding(
              left: 16,
              top: 30,
              right: 24,
            ),
            child: Text(
              "Войти",
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.start,
              style: TextStyle(
                fontSize: getFontSize(
                  23,
                ),
                fontFamily: 'Source Sans Pro',
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Container(
            width: double.infinity,
            margin: getMargin(
              left: 24,
              top: 30,
              right: 24,
            ),
            decoration: const BoxDecoration(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.center,
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        getHorizontalSize(
                          2.00,
                        ),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: getPadding(
                            left: 24,
                            right: 24,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: getPadding(),
                                child: Text(
                                  "Логин",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    color: isDark
                                        ? Colors.white
                                        : ColorConstant.bluegray800A2,
                                    fontSize: getFontSize(
                                      16,
                                    ),
                                    fontFamily: 'Source Sans Pro',
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  bottom: 5,
                                ),
                                child: Text(
                                  "*",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    color: ColorConstant.redA700A2,
                                    fontSize: getFontSize(
                                      14,
                                    ),
                                    fontFamily: 'Source Sans Pro',
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                              boxShadow: isDark
                                  ? customDarkBoxShadow
                                  : customBoxShadow),
                          child: CustomTextFormField(
                            controller: emailController,
                            isDark: isDark,
                            width: size.width,
                            focusNode: FocusNode(),
                            hintText: "Email",
                            margin: getMargin(
                              top: 11,
                            ),
                            alignment: Alignment.centerLeft,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Container(
            width: double.infinity,
            margin: getMargin(
              left: 24,
              top: 20,
              right: 24,
            ),
            decoration: const BoxDecoration(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        getHorizontalSize(
                          2.00,
                        ),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: getPadding(
                            left: 24,
                            top: 1,
                            right: 24,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: getPadding(
                                  top: 3,
                                ),
                                child: Text(
                                  "Пароль",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    color: isDark
                                        ? Colors.white
                                        : ColorConstant.bluegray800A2,
                                    fontSize: getFontSize(
                                      16,
                                    ),
                                    fontFamily: 'Source Sans Pro',
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  bottom: 5,
                                ),
                                child: Text(
                                  "*",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.start,
                                  style: TextStyle(
                                    color: ColorConstant.redA700A2,
                                    fontSize: getFontSize(
                                      14,
                                    ),
                                    fontFamily: 'Source Sans Pro',
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                              boxShadow: isDark
                                  ? customDarkBoxShadow
                                  : customBoxShadow),
                          child: CustomTextFormField(
                            controller: passwordController,
                            isDark: isDark,
                            width: size.width,
                            focusNode: FocusNode(),
                            hintText: "Password",
                            margin: getMargin(
                              top: 11,
                            ),
                            textInputAction: TextInputAction.done,
                            alignment: Alignment.center,
                            suffix: Container(
                              margin: getMargin(
                                left: 24,
                                right: 24,
                              ),
                              child: InkWell(
                                onTap: () {
                                  setState(() {
                                    print("chaning obscure");
                                    obscure = !obscure;
                                  });
                                },
                                child: CommonImageView(
                                  imagePath: obscure
                                      ? ImageConstant.visibilityOff
                                      : ImageConstant.visibilityOn,
                                ),
                              ),
                            ),
                            suffixConstraints: BoxConstraints(
                              maxWidth: getHorizontalSize(
                                74.00,
                              ),
                              maxHeight: getVerticalSize(
                                24.00,
                              ),
                            ),
                            isObscureText: obscure,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Align(
            alignment: Alignment.centerLeft,
            child: Row(children: [
              CustomCheckbox(
                alignment: Alignment.centerLeft,
                text: "Запомнить меня",
                iconSize: 16,
                value: checkbox,
                padding: getPadding(
                  left: 48,
                  top: 22,
                  right: 48,
                ),
                onChange: (value) {
                  checkbox = value;
                  setState(() {});
                },
              ),
              Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: getPadding(
                    left: 24,
                    top: 20,
                    right: 24,
                  ),
                  child: InkWell(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) =>
                                const ForgotPasswordMethodScreen()),
                      );
                    },
                    child: Text(
                      "Забыли пароль?",
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: ColorConstant.blueA400,
                        fontSize: getFontSize(
                          16,
                        ),
                        fontFamily: 'Source Sans Pro',
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              )
            ])),
        ValueListenableBuilder<bool>(
            valueListenable: _isFormValid,
            builder: (context, isValid, child) {
              return CustomButton(
                  isDark: isDark,
                  width: size.width,
                  text: "Войти в систему",
                  margin: getMargin(
                    left: 24,
                    top: 22,
                    right: 24,
                  ),
                  variant: ButtonVariant.FillBlueA400,
                  fontStyle: ButtonFontStyle.SourceSansProSemiBold18,
                  alignment: Alignment.center,
                  onTap: () async {
                    /*if (forceUserLogin) {
                      emailController.text = testUserLogin;
                      passwordController.text = testUserPassword;
                    }*/
                    var authRes = await authUser(
                        context, emailController.text, passwordController.text);
                    if (authRes == true) {
                      gogo(isDark);
                    }
                  });
            }),
        Align(
          alignment: Alignment.center,
          child: Padding(
            padding: getPadding(
              left: 24,
              top: 20,
              right: 24,
            ),
            child: Text(
              "или",
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.start,
              style: TextStyle(
                fontSize: getFontSize(
                  16,
                ),
                fontFamily: 'Source Sans Pro',
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ),
        Align(
          alignment: Alignment.center,
          child: Padding(
              padding: getPadding(
                left: 24,
                top: 27,
                right: 24,
              ),
              child: FloatingActionButton.large(
                backgroundColor: ColorConstant.fromHex('F0F7FE'),
                onPressed: () async {
                  final response = await _flutterLoginYandexPlugin.signIn();
                  print(response);

                  if (response!['token'] != null) {
                    _token = response['token'] as String;
                    var userData = await fetchYaUserData(_token);
                    print(userData);
                    var yaRegRes = await regUser(
                        context,
                        userData['login'].contains("@")
                            ? 'pan_' + userData['login']
                            : 'pan_' + userData['login'] + '@fake.ru',
                        'tanya' + userData['id'],
                        'doctor');
                    print(yaRegRes);
                    print("<<");
                    if (yaRegRes == true) {
                      print("updating fields");
                      var yaAuthRes = await authUser(
                          context,
                          userData['login'].contains("@")
                              ? 'pan_' + userData['login']
                              : 'pan_' + userData['login'] + '@fake.ru',
                          'tanya' + userData['id']);

                      var yaupdate = await updateProfileFields(context,
                          email: userData['login'].contains("@")
                              ? 'pan_' + userData['login']
                              : 'pan_' + userData['login'] + '@fake.ru',
                          first_name: userData['first_name'],
                          last_name: userData['last_name'],
                          phone: userData['default_phone'] != null
                              ? userData['default_phone']['number']
                              : '');

                      print("trying to auth yandex user one more time");
                      var yaAuthRes2 = await authUser(
                          context,
                          userData['login'].contains("@")
                              ? 'pan_' + userData['login']
                              : 'pan_' + userData['login'] + '@fake.ru',
                          'tanya' + userData['id']);

                      if (yaAuthRes2 == true) {
                        gogo(isDark);
                      }
                    }
                  } else {
                    _token = response!['error'] as String;
                  }
                },
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.0),
                    color: Colors.white,
                  ),
                  padding: EdgeInsets.all(12.0),
                  child: Image.asset(
                    'assets/images/logos--yandex-ru.png',
                    //width: 40.0,
                    //height: 40.0,
                    fit: BoxFit.cover,
                  ),
                ),

                ///assets/images/logos--yandex-ru.png
              )),
          /* HorizontalSpace(width: 16),
                        Expanded(
                          child: CustomButton(
                            onTap: () async {
                              final response =
                                  await _flutterLoginYandexPlugin.signOut();
                              print(response);
                              setState(() {
                                _token = '';
                              });
                            },
                            isDark: isDark,
                            width: 178,
                            text: "Клиент",
                            variant: ButtonVariant.OutlineGray100,
                            shape: ButtonShape.RoundedBorder12,
                            fontStyle: ButtonFontStyle.SourceSansProSemiBold16,
                            prefixWidget: Container(
                              margin: getMargin(
                                right: isRtl ? 0 : 12,
                                left: isRtl ? 12 : 0,
                              ),
                              child: CommonImageView(
                                svgPath: ImageConstant.imgGoogle,
                              ),
                            ),
                          ),
                        ),*/
        ),
        Align(
          alignment: Alignment.center,
          child: Padding(
            padding: getPadding(
              left: 24,
              top: 37,
              right: 24,
              bottom: 20,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: getPadding(
                    bottom: 1,
                  ),
                  child: Text(
                    "Нет аккаунта?",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: ColorConstant.bluegray400,
                      fontSize: getFontSize(
                        16,
                      ),
                      fontFamily: 'Source Sans Pro',
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                HorizontalSpace(width: 8),
                InkWell(
                  onTap: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const SignUpBlankScreen()),
                    );
                  },
                  child: Text(
                    "Регистрация",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.start,
                    style: TextStyle(
                      color: ColorConstant.blueA400,
                      fontSize: getFontSize(
                        16,
                      ),
                      fontFamily: 'Source Sans Pro',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    ))));
  }
}
