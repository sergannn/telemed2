// import 'proactivity_manager.dart';

// void checkLocationTrigger(double latitude, double longitude) {
//   // Здесь логика проверки местоположения
//   if (/* условие */) {
//     ProactivityManager().addTrigger(
//       ProactivityTrigger('location', 'User entered specific area')
//     );
//   }
// }